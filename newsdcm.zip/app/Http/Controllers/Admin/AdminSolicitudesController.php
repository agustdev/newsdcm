<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Movimientos;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\EstadisticasExport;

class AdminSolicitudesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $solicitudes = Movimientos::WhereIn('estado', ['Enviado', 'En proceso'])->get();
        return view('admin.solicitudes.index', compact('solicitudes'));
    }

    public function alertas()
    {
    }

    public function exportarEstadisticas()
    {
        return Excel::download(new EstadisticasExport, 'estadisticas-movimientos-' . date('d-m-Y H:i:s') . '.xlsx');
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Movimientos $solicitud)
    {
        $estados = array('En proceso', 'Aprobado', 'Rechazado', 'Cancelado');
        if (!in_array($solicitud->estado, $estados)) {
            $solicitud->update(
                [
                    'estado' => 'En proceso'
                ]
            );
        }
        return view('admin.solicitudes.show', compact('solicitud'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Movimientos $solicitud)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Movimientos $solicitud)
    {
        $solicitud->update([
            'estado' => $request->estado
        ]);

        return redirect()->route('admin.solicitudes.show', $solicitud)->with('msj', 'ok');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Movimientos $solicitud)
    {
        //
    }
}
