<a href="/">
    <img class="mx-auto w-56 h-48 mb-2"
        src="https://cdp.mil.do/sdcm/sistema_cdp/html5/new_assets/images/LOGO_CDP_normal.png" alt="">
    <h2 class="h2 text-center mt-5 text-bold">SISTEMA DE CONTROL MARITIMO</h2>
</a>