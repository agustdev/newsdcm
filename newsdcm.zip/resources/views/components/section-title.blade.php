<div class="card-header">
    <h3 class="h3">{{ $title }}</h3>
    <p>{{ $description }}</p>
</div>
