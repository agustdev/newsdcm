<div class="card-header">
    <h3 class="h3"><?php echo e($title); ?></h3>
    <p><?php echo e($description); ?></p>
</div>
<?php /**PATH E:\laragon\www\newsdcm\resources\views/components/section-title.blade.php ENDPATH**/ ?>