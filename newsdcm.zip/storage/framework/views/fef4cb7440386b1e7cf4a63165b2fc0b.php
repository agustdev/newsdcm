<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('titulo', 'Listado de mis embarcaciones'); ?>
    <?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css" />
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>

    <?php $__env->stopPush(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h2 mb-2 mt-2">
            <?php echo e(__('Mis embarcaciones')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="alert alert-info">
        <h2 class="h3">
            <i class="mdi mdi-folder-information mdi-24px"></i> Esta es la lista de tus <strong>embarcaciones</strong>
        </h2>
    </div>
    <div class="row">

        
        <?php $embarcaciones = auth()->user()->embarcaciones ?>
        <?php $__currentLoopData = $embarcaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xxl-3 col-lg-6">
            
            <div
                class="card widget-flat border <?php if(strtotime($emb->fecha_validez->format('d-m-Y')) >= strtotime(\Carbon\Carbon::now()->format('d-m-Y'))): ?> border-custom <?php else: ?> border-custom-red <?php endif; ?> border-5 rounded sombra">
                <div class="card-body">
                    <div class="float-end">
                        <i class="mdi mdi-ship-wheel mdi-36px widget-icon bg-custom rounded-circle text-warning"></i>
                    </div>
                    <h5 class="text-muted fw-normal mt-0" title="Revenue"><strong>Fecha de expiración:</strong>
                        <?php if(strtotime($emb->fecha_validez->format('d-m-Y')) >=
                        strtotime(\Carbon\Carbon::now()->format('d-m-Y'))): ?>
                        <small class="badge bg-success me-1 h2 py-1"><?php echo e($emb->fecha_validez->format('d-m-Y')); ?></small>
                        <?php else: ?>
                        <small class="badge bg-danger me-1 h2 py-1"><?php echo e($emb->fecha_validez->format('d-m-Y')); ?></small>
                        <?php endif; ?>
                    </h5>
                    <div class="col-lg-12">
                        <p class="mb-2 text-muted ">
                            <span class="badge badge-outline-success me-1 font-weight-bold py-1">
                                <i class="uil-ship uil-16-plus me-1" style="font-size: 24px;"></i> <span
                                    style="vertical-align: super; font-size: 14px;"><?php echo e($emb->nombre); ?>

                                </span>
                            </span>
                        </p>
                        <p class="mb-2 text-muted ">
                            <span class="badge badge-outline-info me-1 py-1">
                                <i class="mdi mdi-card-account-details mdi-48px me-1"></i> <span
                                    style="vertical-align: super; font-size: 14px;"><?php echo e($emb->matricula); ?></span>
                            </span>
                        </p>
                        <p class="text-muted ">
                            <span class="badge badge-outline-danger me-1 py-1">
                                <i class="mdi mdi-card-text mdi-36px me-1"></i>
                                <span style="vertical-align: super; font-size: 14px;">CHASIS: <?php echo e($emb->no_chasis); ?></span>
                            </span>
                        </p>
                    </div>
                </div>
                <div class="card-footer">
                    <small>Ultima solicitud: <?php echo e(!empty($emb->movimiento->last()) ?
                        $emb->movimiento->last()->created_at->diffForHumans() : ''); ?></small>

                    <h3 class="mt-0 mb-1 "><strong>Solicitudes realizadas:</strong>
                        <small class="badge bg-warning me-1 py-1"><?php echo e(0); ?></small>
                    </h3>
                    <div class="d-grid mt-2 col-lg-12">
                        <?php if(strtotime($emb->fecha_validez->format('d-m-Y')) >=
                        strtotime(\Carbon\Carbon::now()->format('d-m-Y'))): ?>

                        <button type="button"
                            class="items-center px-3 py-2 bg-blue-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 ml-1 block"
                            data-bs-toggle="modal" data-bs-target="#option-mov-modal-<?php echo e($emb->id); ?>">SOLICITAR</button>
                        <?php else: ?>
                        <button type="button" disabled
                            class="items-center px-3 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 ml-1 disabled:opacity-25 block">SOLICITAR</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Standard modal -->
        <div id="option-mov-modal-<?php echo e($emb->id); ?>" class="modal fade" tabindex="-1" role="dialog"
            aria-labelledby="standard-modalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title h3" id="standard-modalLabel">MOVIMIENTOS A SOLICITAR</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                    </div>
                    <div class="modal-body text-center">
                        <a href="<?php echo e(route('despachos.createpost')); ?>"
                            class="items-center px-3 py-2 bg-blue-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 ml-1 url_despacho"
                            onclick="event.preventDefault(); document.getElementById('despacho-form-<?php echo e($emb->id); ?>').submit();">DESPACHO

                        </a>
                        <form id="despacho-form-<?php echo e($emb->id); ?>" action="<?php echo e(route('despachos.createpost')); ?>"
                            method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="emb" value="<?php echo e($emb->matricula); ?>">
                        </form>

                        <a href="<?php echo e(route('conduces.createpost')); ?>"
                            class="items-center px-3 py-2 bg-yellow-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-yellow-700 focus:bg-yellow-700 active:bg-yellow-900 focus:outline-none focus:ring-2 focus:ring-yellow-600 focus:ring-offset-2 transition ease-in-out duration-150 ml-1 url_conduce"
                            onclick="event.preventDefault(); document.getElementById('conduce-form-<?php echo e($emb->id); ?>').submit();">CONDUCE</a>

                        <form id="conduce-form-<?php echo e($emb->id); ?>" action="<?php echo e(route('conduces.createpost')); ?>" method="POST"
                            class="d-none">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="emb" value="<?php echo e($emb->matricula); ?>">
                        </form>

                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH E:\laragon\www\newsdcm\resources\views/embarcaciones/index.blade.php ENDPATH**/ ?>