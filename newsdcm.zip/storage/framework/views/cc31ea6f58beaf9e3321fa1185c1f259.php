<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('titulo', 'Detalle de la solicitud'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="h3 mb-3">
                        Detalle
                        tipo movimiento:
                        <?php if($solicitud->tipo_movimiento == 'D'): ?>
                        Despacho
                        <?php else: ?>
                        Conduce
                        <?php endif; ?>
                    </h3>
                </div>
                <div class="card-body">
                    <h5 class="header-title"><strong>Número solicitud:</strong> <?php echo e($solicitud->id); ?></h5>
                    <h5 class="header-title"><strong>Fecha Solicitud:</strong> <?php echo e($solicitud->created_at->format('d-m-Y')); ?></h5>
                    <h5 class="header-title border-bottom py-2"><strong>Estatus:</strong>
                        <?php if($solicitud->estado == "Aprobado"): ?>
                        <span
                            class="bg-green-100 text-green-600 text-sm font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-green-700 dark:text-green-300"><?php echo e($solicitud->estado); ?></span>
                        <?php elseif($solicitud->estado == "Rechazado" or $solicitud->estado == "Cancelado"): ?>
                        <span
                            class="bg-red-100 text-red-600 text-sm font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-red-700 dark:text-red-300"><?php echo e($solicitud->estado); ?></span>
                        <?php elseif($solicitud->estado == "Enviado"): ?>
                        <span
                            class="bg-yellow-100 text-yellow-600 text-sm font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-yellow-700 dark:text-yellow-300"><?php echo e($solicitud->estado); ?></span>
                        <?php elseif($solicitud->estado == "En proceso"): ?>
                        <span
                            class="bg-blue-100 text-blue-600 text-sm font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-blue-700 dark:text-blue-300"><?php echo e($solicitud->estado); ?></span>
                        <?php endif; ?>
                    </h5>
                    
                    <h4 class="header-title mt-3">
                        <div class="alert alert-warning" role="alert">
                            <strong>INFORMACIÓN DE LA EMBARCACIÓN</strong>
                        </div>
                        <p class="mb-2 mt-2">
                            <strong>Matrícula:</strong> <?php echo e($solicitud->matricula); ?>

                        </p>
                        <p>
                            <strong>Nombre de la Embarcación:</strong> <?php echo e($solicitud->nombre); ?>

                        </p>
                        <p class="mt-2">
                            <strong>No Chasis:</strong> <?php echo e($solicitud->numero_casco); ?>

                        </p>
                        <p class="mt-2">
                            <strong>Cantidad de Tripulantes:</strong> <?php echo e($solicitud->embarcacion->capacidad_personas); ?>

                        </p>
                        <p class="mt-2">
                            <strong>Cantidad de Pasajeros:</strong> <?php echo e($solicitud->embarcacion->capacidad_tripulantes); ?>

                        </p>
                        <p class="mt-2">
                            <strong>Tipo tripulación:</strong> <?php echo e($solicitud->embarcacion->tipo_embarcacion); ?>

                        </p>

                    </h4>
                    
                    <?php if($solicitud->tipo_movimiento == 'D'): ?>
                    
                    <?php if(!empty($solicitud->capitan)): ?>
                    <h4 class="header-title mt-3">
                        <div class="alert alert-info mt-2" role="alert">
                            <strong>INFORMACIÓN DEL CAPITÁN</strong>
                        </div>
                        <p class="mb-2 mt-2">
                            <strong>Nombre:</strong> <?php echo e(!empty($solicitud->capitan) ? $solicitud->capitan->nombre : ''); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Documento:</strong> <?php echo e(!empty($solicitud->capitan) ? $solicitud->capitan->documento
                            :
                            ''); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Teléfono:</strong> <?php echo e(!empty($solicitud->capitan) ? $solicitud->capitan->telefono :
                            ''); ?>

                        </p>
                        <p class="mb-2 mt-2 py-2">
                            <strong>Motivo del viaje:</strong> <?php echo e(!empty($solicitud->capitan) ?
                            $solicitud->capitan->motivo_viaje : ''); ?>

                        </p>
                        <p>
                            <strong>Fecha Salida:</strong>
                            <?php echo e($solicitud->fecha->format('d-m-Y')); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Lugar salida:</strong> <?php echo e(!empty($solicitud->capitan) ?
                            $solicitud->capitan->lugar_salida : ''); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Lugar destino:</strong> <?php echo e(!empty($solicitud->capitan) ?
                            $solicitud->capitan->lugar_destino : ''); ?>

                        </p>
                    </h4>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <strong>SOLICITUD INCOMPLETA</strong>
                    </div>
                    <?php endif; ?>
                    <?php else: ?>
                    <?php if(!empty($solicitud->conductor)): ?>
                    <h4 class="header-title mt-3">
                        <div class="alert alert-info mt-2" role="alert">
                            <strong>INFORMACIÓN DEL CONDUCTOR</strong>
                        </div>
                        <p class="mb-2 mt-2">
                            <strong>Nombre:</strong> <?php echo e($solicitud->conductor->nombre); ?>

                        </p>
                        <p>
                            <strong>Documento:</strong> <?php echo e($solicitud->conductor->documento); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Teléfonos:</strong> <?php echo e(str_replace("|",", ",$solicitud->conductor->telefono)); ?>

                        </p>
                        <p>
                            <strong>Fecha Salida:</strong>
                            <?php echo e($solicitud->fecha->format('d-m-Y')); ?>

                        </p>
                    </h4>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <strong>SOLICITUD INCOMPLETA FALTA INFORMACIÓN DEL CONDUCTOR</strong>
                    </div>
                    <?php endif; ?>
                    <?php if(!empty($solicitud->vehiculo)): ?>
                    <h4 class="header-title mt-3">
                        <div
                            class="bg-gray-100 text-gray-600 text-sm font-medium mr-2 px-2.5 py-1.5 mb-1 rounded dark:bg-gray-700 dark:text-gray-300">
                            DATOS DEL VEHÍCULO
                        </div>
                        <p class="mb-2 mt-2">
                            <strong>MArca:</strong> <?php echo e($solicitud->vehiculo->marca); ?>

                        </p>
                        <p>
                            <strong>Color:</strong> <?php echo e($solicitud->vehiculo->color); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Año:</strong> <?php echo e($solicitud->vehiculo->year); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Placa:</strong> <?php echo e($solicitud->vehiculo->placa); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Provincia:</strong> <?php echo e($solicitud->vehiculo->provincia); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Municipio:</strong> <?php echo e($solicitud->vehiculo->municipio); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>sector:</strong> <?php echo e($solicitud->vehiculo->sector); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>calle:</strong> <?php echo e($solicitud->vehiculo->calle); ?>

                        </p>
                        <p class="mb-2 mt-2">
                            <strong>Observación:</strong> <?php echo e($solicitud->vehiculo->observacion); ?>

                        </p>
                    </h4>
                    <?php else: ?><div class="alert alert-danger">
                        <strong>SOLICITUD INCOMPLETA FALTA INFORMACIÓN DEL VEHÍCULO</strong>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="card-footer">
                    <div class="float-end">
                        <?php
                        $estados = array("Rechazado", "En proceso", "Cancelado", "Enviado");
                        ?>
                        <a href="<?php echo e(route('admin.solicitudes.index')); ?>"
                            class="inline-flex items-center px-3 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 ml-1">
                            <i class="mdi mdi-location-exit mdi-18px"></i> Atras</a>
                        <?php if($solicitud->estado == $estados[1] or $solicitud->estado == $estados[3]): ?>

                        <form id="aprove-form" action="<?php echo e(route('admin.solicitudes.update', $solicitud)); ?>"
                            method="POST" class="inline-block aprove">
                            <?php echo method_field('PATCH'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="inline-flex items-center justify-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-500 active:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition ease-in-out duration-150 ml-1"><i
                                    class="mdi mdi-progress-check mdi-18px"></i> Aprobar</button>
                            <input type="hidden" name="estado" value="Aprobado">
                        </form>

                        <form id="denied-form" action="<?php echo e(route('admin.solicitudes.update', $solicitud)); ?>"
                            method="POST" class="inline-block denied">
                            <?php echo method_field('PATCH'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150 ml-1">
                                <i class="mdi mdi-cancel mdi-18px"></i> Rechazar</button>
                            <input type="hidden" name="estado" value="Rechazado">
                        </form>
                        <?php endif; ?>

                        <?php if(!in_array($solicitud->estado, $estados)): ?>
                        <a href="#"
                            class="inline-flex items-center justify-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-500 active:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition ease-in-out duration-150">
                            <i class="mdi mdi-printer-eye mdi-18px"></i> Previsualizar</a>
                        <a href="#"
                            class="inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150">
                            <i class="mdi mdi-file-pdf-outline mdi-18px"></i> Descargar PDF
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
    <?php if(Session::get('msj')): ?>
    <script>
        Swal.fire(
            'Buen trabajo!'
            , 'Se ha realizado la acción seleccionada'
            , 'success'
        )

    </script>
    <?php endif; ?>
    <script type="text/javascript">
        $('.aprove').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: '¿Estas seguro de aprobar esta solicitud?'
                    , text: "¡Esta acción no podra ser revertida!"
                    , showCancelButton: true
                    , confirmButtonColor: '#2563EB'
                    , cancelButtonColor: '#DC2626'
                    , confirmButtonText: '¡Si, aprobar!'
                    , cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });

            $('.denied').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: '¿Estas seguro de rechazar esta solicitud?'
                    , text: "¡Esta acción no podra ser revertida!"
                    , showCancelButton: true
                    , confirmButtonColor: '#2563EB'
                    , cancelButtonColor: '#DC2626'
                    , confirmButtonText: '¡Si, rechazar!'
                    , cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
    
    </script>

    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH E:\laragon\www\newsdcm\resources\views/admin/solicitudes/show.blade.php ENDPATH**/ ?>