<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('titulo', 'Dashboard'); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h2">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        
        <div class="flex  flex-col items-center justify-center py-4 sm:py-12">
            <div class="flex space-x-6" id="widget">
                <div
                    class="flex h-48 w-64 flex-col items-center justify-center rounded-lg bg-white border-4 border-gray-500 hover:border-gray-800 transition ease-in-out duration-50">
                    <div class="flex flex-col space-x-2 text-center">
                        <i class="dripicons-to-do text-muted mb-3" style="font-size: 24px;"></i>
                        <div class="text-center text-4xl font-bold"><?php echo e($total_movimientos); ?></div>
                        <div class="my-2 text-center text-gray-700 text-bold">
                            TOTAL DE SOLICITUDES
                        </div>
                    </div>
                </div>
                <div
                    class="flex h-48 w-64 flex-col items-center justify-center rounded-lg bg-white border-4 border-green-600 hover:border-green-800 transition ease-in-out duration-50">
                    <div class="flex flex-col space-x-2 text-center">
                        <i class="dripicons-checkmark mb-3" style="font-size: 24px; color:green;"></i>
                        <div class="text-center text-4xl font-bold"><?php echo e($total_aprove_movimientos); ?></div>
                        <div class="my-2 text-center text-gray-500">
                            TOTAL SOLICITUDES APROBADAS
                        </div>

                    </div>
                </div>
                <div
                    class="flex h-48 w-64 flex-col items-center justify-center rounded-lg bg-white border-4 border-blue-500 hover:border-blue-800 transition ease-in-out duration-50">
                    <div class="flex flex-col space-x-2 text-center">
                        <i class="dripicons-clock mb-3" style="font-size: 24px; color:blue;"></i>
                        <div class="text-center text-4xl font-bold"><?php echo e($total_pendent_movimientos); ?></div>
                        <div class="my-2 text-center text-gray-500">
                            TOTAL SOLICITUDES PENDIENTES
                        </div>

                    </div>
                </div>
                <div
                    class="flex h-48 w-64 flex-col items-center justify-center rounded-lg bg-white border-4 border-red-500 hover:border-red-800 transition ease-in-out duration-50">
                    <div class="flex flex-col space-x-2 text-center">
                        <i class="dripicons-cross mb-3" style="font-size: 24px; color:red;"></i>
                        <div class="text-center text-4xl font-bold"><?php echo e($total_denied_movimientos); ?></div>
                        <div class="my-2 text-center text-gray-500">
                            SOLICITUDES RECHAZADAS
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="flex  flex-col items-center justify-center py-4 sm:py-12">
            <div class="flex space-x-6" id="widget">
                <div
                    class="flex h-48 w-64 flex-col items-center justify-center rounded-lg bg-white border-4 border-gray-500 hover:border-gray-800 transition ease-in-out duration-50">
                    <div class="flex flex-col space-x-2 text-center">
                        <i class="dripicons-user-group text-muted" style="font-size: 24px;"></i>
                        <div class="text-center text-4xl font-bold"><?php echo e($total_usuarios); ?></div>
                        <div class="my-2 text-center text-gray-700 text-bold">
                            TOTAL DE USUARIOS PROPIETARIOS
                        </div>
                    </div>
                </div>
                <div
                    class="flex h-48 w-64 flex-col items-center justify-center rounded-lg bg-white border-4 border-green-600 hover:border-green-800 transition ease-in-out duration-50">
                    <div class="flex flex-col space-x-2 text-center">
                        <i class="dripicons-user-group text-muted" style="font-size: 24px;"></i>
                        <div class="text-center text-4xl font-bold"><?php echo e($total_usuarios_admins); ?></div>
                        <div class="my-2 text-center text-gray-500">
                            TOTAL DE USUARIOS ADMINISTRATIVOS
                        </div>

                    </div>
                </div>
                <div
                    class="flex h-48 w-64 flex-col items-center justify-center rounded-lg bg-white border-4 border-yellow-500 hover:border-yellow-800 transition ease-in-out duration-50">
                    <div class="flex flex-col space-x-2 text-center">
                        <i class="uil-ship" style="font-size: 24px; color:#9c690a;"></i>
                        <div class="text-center text-4xl font-bold"><?php echo e($total_embarcaciones); ?></div>
                        <div class="my-2 text-center text-gray-500">
                            TOTAL EMBARCACIONES MATRICULADAS
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH E:\laragon\www\newsdcm\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>