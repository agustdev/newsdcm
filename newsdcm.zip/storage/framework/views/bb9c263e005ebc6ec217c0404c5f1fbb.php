<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>SDCM | Sistema de Control Maritimo - CDP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Sistema de control Maritimo" name="description">
    <meta content="Capitania de Puertos y Autoridad Maritima" name="author">
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/capitania_web2_sm.png')); ?>">

    <!-- App css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style">
    <link href="assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style">

</head>

<body class="loading" data-layout-config='{"darkMode":true}'>

    <!-- NAVBAR START -->
    <nav class="navbar navbar-expand-lg py-lg-3 navbar-dark">
        <div class="container">

            <!-- logo -->
            <a href="/" class="navbar-brand me-lg-5">
                <img src="<?php echo e(asset('assets/images/capitania_web2.png')); ?>" alt="" height="96">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>

            <!-- menus -->
            <div class="collapse navbar-collapse" id="navbarNavDropdown">

                <!-- left menu -->
                

                <!-- right menu -->
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item me-0">
                        <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link d-lg-none">SDCM</a>
                        <a href="<?php echo e(route('dashboard')); ?>"
                            class="btn btn-sm btn-warning btn-rounded d-none d-lg-inline-flex">
                            <i class="mdi mdi-ship-wheel me-2"></i> SDCM
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="nav-link d-lg-none">Iniciar Sesión</a>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-light btn-rounded d-none d-lg-inline-flex">
                            <i class="mdi mdi-account-key me-2"></i> Iniciar Sesión
                        </a>
                        <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="nav-link d-lg-none">Registro</a>
                        <a href="<?php echo e(route('register')); ?>"
                            class="btn btn-sm btn-light btn-rounded d-none d-lg-inline-flex">
                            <i class="mdi mdi-account-plus me-2"></i> Registro
                        </a>
                        <?php endif; ?>
                        <?php endif; ?>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
    <!-- NAVBAR END -->

    <!-- START HERO -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-5">
                    <div class="mt-md-4">
                        <div>
                            <span class="badge bg-danger rounded-pill">Nuevo</span>
                            <span class="text-white-50 ms-1">Bienvenidos al Sistema de Control Maritimo</span>
                        </div>
                        <h2 class="text-white fw-normal mb-4 mt-3 hero-title">

                        </h2>
                        <p class="mb-4 font-16 text-white-50"></p>
                        
                    </div>
                </div>
                <div class="col-md-5 offset-md-2">
                    <div class="text-md-end mt-3 mt-md-0">
                        <img src="assets/images/startup.svg" alt="" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END HERO -->

    <!-- START SERVICES -->
    
    <!-- END SERVICES -->

    <!-- START FEATURES 1 -->
    
    <!-- END FEATURES 1 -->

    <!-- START FEATURES 2 -->
    
    <!-- END FEATURES 2 -->

    <!-- START PRICING -->
    
    <!-- END PRICING -->

    <!-- START FAQ -->
    
    <!-- END FAQ -->


    <!-- START CONTACT -->
    
    <!-- END CONTACT -->

    <!-- START FOOTER -->
    <footer class="bg-dark py-5">
        <div class="container">
            

            <div class="row">
                <div class="col-lg-12">
                    <div class="mt-5">
                        <p class="text-muted mt-4 text-center mb-0">© <?php echo e(date('Y')); ?> SDCM - Comando Naval de Capitanias
                            de Puerto y Autoridad Maritima (CDP)</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- END FOOTER -->

    <!-- bundle -->
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>

</body>

</html><?php /**PATH E:\laragon\www\newsdcm\resources\views/welcome.blade.php ENDPATH**/ ?>