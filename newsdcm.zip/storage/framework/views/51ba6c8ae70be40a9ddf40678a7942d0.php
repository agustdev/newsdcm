<ul class="side-nav">
    <li class="side-nav-title side-nav-item">NAVEGACIóN</li>
    <li class="side-nav-item <?php echo e(request()->is('dashboard*') ? 'menuitem-active' : ''); ?>">
        <a href="<?php echo e(route('admin.dashboard')); ?>"
            class="side-nav-link <?php echo e(request()->is('dashboard*') ? 'menuitem-active' : ''); ?>">
            <i class="mdi mdi-gauge"></i>
            <span>Panel</span>
        </a>
    </li>
    <li class="side-nav-title side-nav-item">ACTIVIDADES</li>
    <li
        class="side-nav-item <?php echo e(request()->is('admin/solicitudes*') ? 'menuitem-active' : ''); ?> <?php echo e(request()->is('admin/solicitud*') ? 'menuitem-active' : ''); ?>">
        <a href="<?php echo e(route('admin.solicitudes.index')); ?>"
            class="side-nav-link <?php echo e(request()->is('admin/solicitudes*') ? 'active' : ''); ?><?php echo e(request()->is('admin/solicitud*') ? 'active' : ''); ?>">
            <i class="uil-document-layout-center"></i>
            <?php if(get_all_count_solicitudes() > 0): ?>
            <span class="badge bg-danger float-end"><?php echo e(get_all_count_solicitudes()); ?></span>
            <?php endif; ?>
            <span>Solicitudes</span>
        </a>
    </li>
    <li class="side-nav-item">
        <a href="#" class="side-nav-link">
            <i class="uil-bell"></i>
            <span>Alertas</span>
        </a>
    </li>
    <li class="side-nav-title side-nav-item">AREA ADMINISTRATIVA</li>
    <li class="side-nav-item">
        <a href="#" class="side-nav-link">
            <i class="uil-user"></i>
            <span> Usuarios </span>
        </a>
    </li>
    
    
</ul><?php /**PATH E:\laragon\www\newsdcm\resources\views/layouts/admin/partials/menu.blade.php ENDPATH**/ ?>