<ul class="side-nav">
    <li class="side-nav-title side-nav-item">Actividad</li>
    <li class="side-nav-item <?php echo e(request()->is('quick-access*') ? 'menuitem-active' : ''); ?>">
        <a href="<?php echo e(route('acceso.rapido')); ?>"
            class="side-nav-link <?php echo e(request()->is('quick-access*') ? 'menuitem-active' : ''); ?>">
            <i class="mdi mdi-ship-wheel"></i>
            <span>Acceso rápido</span>
        </a>
    </li>
    <li class="side-nav-item">
        <a href="<?php echo e(route('embarcaciones.index')); ?>" class="side-nav-link">
            <i class="mdi mdi-ship-wheel"></i>
            <span>Mis Embarcaciones</span>
        </a>
    </li>

    <li class="side-nav-item <?php echo e(request()->is('despachos*') ? 'menuitem-active' : ''); ?>">
        <a href="<?php echo e(route('movimientos.despachos.index')); ?>"
            class="side-nav-link <?php echo e(request()->is('despachos*') ? 'active' : ''); ?>">
            <i class="uil-ship"></i>
            <span>Despacho</span>
        </a>
    </li>
    <li class="side-nav-item <?php echo e(request()->is('conduces*') ? 'menuitem-active' : ''); ?>">
        <a href="<?php echo e(route('movimientos.conduces.index')); ?>"
            class="side-nav-link <?php echo e(request()->is('conduces*') ? 'menuitem-active' : ''); ?>">
            <i class="uil-truck-case"></i>
            <span>Conduce</span>
        </a>
    </li>
    
</ul><?php /**PATH E:\laragon\www\newsdcm\resources\views/layouts/template/menu.blade.php ENDPATH**/ ?>