<!-- bundle -->
<script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php echo $__env->yieldPushContent('modals'); ?>
<?php echo $__env->yieldPushContent('js'); ?>

</body>
</html>
<?php /**PATH E:\laragon\www\newsdcm\resources\views/layouts/template/footer.blade.php ENDPATH**/ ?>