<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('titulo', 'Acceso Rápido'); ?>
    <?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css" />

    <?php $__env->stopPush(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h2 mb-2">
            <?php echo e(__('Acceso Rápido')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="row">
        <div class="col-xl-2"></div>
        <div class="col-xl-4">
            <div class="card cta-box bg-primary bg-custom text-white">
                <div class="card-body">
                    <div class="text-center">
                        <h3 class="m-0 fw-normal cta-box-title">DESPACHO</h3>
                        <img class="my-3 text-center mx-auto" src="<?php echo e(asset('images/despacho-icon.png')); ?>" width="180"
                            alt="Generic placeholder image">

                        <br>
                        <a href="<?php echo e(route('movimientos.despachos.create')); ?>"
                            class="btn btn-sm btn-light btn-rounded">SOLICITAR <i class="mdi mdi-arrow-right"></i></a>
                    </div>
                </div>
                <!-- end card-body -->
            </div>
            <!-- end card-->
        </div>
        <div class="col-xl-4">
            <div class="card cta-box bg-primary bg-custom text-white">
                <div class="card-body">
                    <div class="text-center">
                        <h3 class="m-0 fw-normal cta-box-title">CONDUCE</h3>
                        <img class="my-3 text-center mx-auto" src="<?php echo e(asset('images/conduce-icon.png')); ?>" width="180"
                            alt="Generic placeholder image">
                        <br>
                        <a href="<?php echo e(route('movimientos.conduces.create')); ?>"
                            class="btn btn-sm btn-light btn-rounded">SOLICITAR <i class="mdi mdi-arrow-right"></i></a>
                    </div>
                </div>
                <!-- end card-body -->
            </div>
            <!-- end card-->
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH E:\laragon\www\newsdcm\resources\views/quick-access.blade.php ENDPATH**/ ?>